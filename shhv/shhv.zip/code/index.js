const WebSocket = require('ws')
const uuid = require(`uuid`)
const path = require(`path`)
const setting = require(path.join(__dirname, `..`, `setting.js`))
const wss = new WebSocket.Server({ port: setting.port })
const colors = require(`colors`)
const games = [
    "wars",
    "dr",
    "hide",
    "sg",
    "murder",
    "sky",
    "ctf",
    "drop",
    "ground",
    "build",
    "party",
    "main",
    "bridge",
    "grav",
    "bed"
];
console.log(`------------------------------------`)
console.log()
console.log(`Join Our ${"Discord".rainbow} : https://discord.gg/QgEZQtabXc`)
console.log(`Made By ${"MinedPlumr".bold}`)
console.log(`ⓒ 2024. WebSocket Research Team All rights reserved.`)
console.log(`Code Supporter : sanand0, https://github.com/sanand0/minecraft-websocket/tree/master/tutorial#programming-minecraft-with-websockets`)
console.log()
console.log(`------------------------------------`)

console.log()
console.log(`Search Example :`)
console.log(`!!search {gameType} {playerName}`)
console.log(`!!search wars MinedPlumr`)
console.log()
console.log(`=================================`)
console.log(`DOCS :`)
console.log(`gameType : wars, dr, hide, sg, murder, sky, ctf, drop, ground, build, party, main, bridge, grav, bed`)
console.log(`playerName : playerName`)
console.log(`=================================`)
console.log()
console.log(`When you're ready, type "/connect localhost:${setting.port}" in the Minecraft chat.`)
console.log()

wss.on('connection', socket => {
    console.log(`Search Hive has connected`)

    socket.on('message', packet => {
        const pc = JSON.parse(packet)

        if (pc.body.type == `chat`) {
            const sender = pc.body.sender
            const msg = pc.body.message

            if (msg.startsWith(`!!search`)) {
                if (msg.split(' ').length == 3) {
                    const game = msg.split(' ')[1]
                    const player = msg.split(' ')[2]

                    if (games.includes(game)) {
                        const apiUrl = `https://api.playhive.com/v0/game/all/${game}/${player.replace(`-`, `%20`)}`;
                        let ro = false
                        fetch(apiUrl)
                            .then(response => {
                                if (!response.ok) {
                                    console.log(`----------`)
                                    console.log(`Wrong Request: ` + msg)
                                    console.log(player + ` is Unknown player`)
                                    console.log(`----------`)
                                    return
                                } else {
                                    ro = true
                                    return response.json();
                                }
                            })
                            .then(data => {
                                if (ro) {
                                    command(`me ${sender} has checked the game stats of ${player} in The Hive ${game}.`)
                                    Object.keys(data).forEach((r) => {
                                        command(`me ${r} : ${data[r]}`)
                                    })
                                    console.log(`----------`)
                                    console.log(`Successfully Searched: ` + msg)
                                    console.log(`sender : ${sender}`)
                                    console.log(`player : ${player}`)
                                    console.log(`game : ${game}`)
                                    console.log(`----------`)
                                } else {
                                    return
                                }
                            })
                    } else {
                        console.log(`----------`)
                        console.log(`Wrong Request: ` + msg)
                        console.log(game + ` is Unknown game`)
                        console.log(`----------`)
                        return
                    }

                } else { //Search failed
                    console.log(`----------`)
                    console.log(`Wrong Request: ` + msg)
                    console.log(`Search Example: `)
                    console.log(`!!search {gameType} {playerName} `)
                    console.log(`!!search wars MinedPlumr`)
                    console.log(`----------`)
                    return
                }
            } else {
                return
            }
        }
    })

    function command(cmd) {
        const msg = {
            "header": {
                "version": 1,
                "requestId": uuid.v4(),
                "messagePurpose": "commandRequest",
                "messageType": "commandRequest"
            },
            "body": {
                "version": 1,
                "commandLine": cmd,
                "origin": {
                    "type": "player"
                }
            }
        }
        socket.send(JSON.stringify(msg))
    }

    socket.send(JSON.stringify({
        "header": {
            "version": 1,
            "requestId": uuid.v4(),
            "messageType": "commandRequest",
            "messagePurpose": "subscribe"
        },
        "body": {
            "eventName": "PlayerMessage"
        },
    }))
})
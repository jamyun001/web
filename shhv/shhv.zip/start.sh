echo "Search Hive"
node ./code/index.js
read -p "Press enter to continue"
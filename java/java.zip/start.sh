echo "WebSocket JavaScript Runner"
node ./code/index.js
read -p "Press enter to continue"
const setting = {
    port: 3000,
    nickname: "PlumrMined"
}

module.exports = setting
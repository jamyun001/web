const translate = require('@vitalets/google-translate-api');
const maxLength = 200;

const path = require(`path`);
const setting = require(path.join(__dirname, `..`, `setting.js`));
const WebSocket = require("ws");
const uuid = require("uuid");
const colors = require(`colors`);
const wss = new WebSocket.Server({ port: setting.port });
const generated_uuid = uuid.v4();

console.log(`-----------------`);
console.log();
console.log(`Join Our ${"Discord".rainbow} : https://discord.gg/QgEZQtabXc`);
console.log(`Made By ${"MinedPlumr".bold}, ${"wow_1.".bold}`);
console.log(`ⓒ 2024. WebSocket Research Team All rights reserved.`);
console.log(
  `Code Supporter : sanand0, https://github.com/sanand0/minecraft-websocket/tree/master/tutorial#programming-minecraft-with-websockets`
);
console.log();
console.log(`----------------- `);
console.log(`Type '/connect localhost:${setting.port}' in your minecraft chat`)
console.log(`Change name Setting to Your name.`)

wss.on("connection", (socket) => {
  console.log(`Connected to Minecraft Translate.`)
  send(`me §e[ Minecraft Translate ] Connected to Minecraft Translate ( @s )`);

  socket.on("message", (packet) => {
    const msg = JSON.parse(packet);
    if (msg.body.type == `chat`) {
      const sender = msg.body.sender;
      const message = msg.body.message;

      console.log(sender + ` , ` + message)

      if (sender == setting.nickname) { // 이거 안해놓으면 안됨
        translate.translate(message, { to: 'en' }).then(res => {
          const resfilter = res.text.slice(0, maxLength)
          console.log(resfilter);
          send(`/me translated: <${sender}> ${resfilter}`) // 이부분이 번역 결과
        }).catch(err => {
          console.error(err);
        });
      } else {
        translate.translate(message, { to: 'ko' }).then(res => {
          const result = res.text
          console.log(result)
          send(`/tell "${setting.nickname}" translated: <${sender}> ${result}`)
        }).catch(err => {
          console.error(err)
        })
      }
    }
  });

  socket.send(
    JSON.stringify({
      header: {
        version: 1,
        requestId: generated_uuid,
        messageType: "commandRequest",
        messagePurpose: "subscribe",
      },
      body: {
        eventName: "PlayerMessage",
      },
    })
  );

  function send(cmd) {
    const msg = {
      header: {
        version: 1,
        requestId: uuid.v4(),
        messagePurpose: "commandRequest",
        messageType: "commandRequest",
      },
      body: {
        version: 1,
        commandLine: cmd,
        origin: {
          type: "player",
        },
      },
    };
    socket.send(JSON.stringify(msg));
  }

  socket.on("close", function () {
    console.log(`웹소켓 연결 해제됨`)
    process.exit(0);
  });
});
echo "Minecraft AutoReloader"
node ./code/index.js
read -p "Press enter to continue"
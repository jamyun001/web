const colors = require("colors")

const functions = {
    error: function (msg, exit) {
        console.log(colors.red(`ERROR : ` + msg))
        if (exit == `y`) process.exit(1)
        return
    }
}

module.exports = functions
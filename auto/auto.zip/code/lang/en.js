const path = require('path/path')
const setting = require(path.join(__dirname, '..', 'setting.js'))

const enJson = {
    "AutoReloaderIsOn": `To connect, type '/connect localhost:${setting.port}' in the Minecraft chat. (OP permissions required)`,
    "AutoReloaderConnected": "AutoReloader is connected.",
    "AutoReloaderConnectedMinecraft": "§e[ AutoReloader ] AutoReloader is connected. It will automatically reload at the set tick intervals.",
    "HowToStopConnect": "If you want to stop the AutoReloader, type '/connect stop' in the Minecraft chat.",
    "IfNotConnected": "If the connection fails, please refer to Discord.",
}

module.exports = enJson

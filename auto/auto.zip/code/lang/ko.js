const path = require(`path/path`)
const setting = require(path.join(__dirname, `..`, `setting.js`))

const koJson = {
    "AutoReloaderIsOn": `연결하실려면 마인크래프트 채팅에 '/connect localhost:${setting.port}'를 입력하세요. (OP 권한 필요)`,
    "AutoReloaderConnected": "AutoReloader가 연결되었습니다.",
    "AutoReloaderConnectedMinecraft": "§e[ AutoReloader ] AutoReloader가 연결되었습니다. 설정한 틱마다 자동으로 리로드를 합니다",
    "HowToStopConnect": "만약에 autoReloader를 멈추고 싶다면, 마인크래프트 채팅창에 '/connect stop'를 입력하세요.",
    "IfNotConnected": "만약에 연결이 안될시 디스코드를 참조하세요.",
}

module.exports = koJson
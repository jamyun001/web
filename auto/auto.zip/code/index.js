const path = require(`path/path`)
const setting = require(path.join(__dirname, `setting.js`))
const WebSocket = require('./node_modules/ws')
const uuid = require('uuid')
const colors = require(`colors`)
const wss = new WebSocket.Server({ port: setting.port })
const langs = {
    ko: require(path.join(__dirname, `lang`, `ko.js`)),
    en: require(path.join(__dirname, `lang`, `en.js`))
}
const l = langs[setting.lang]
const generated_uuid = uuid.v4()

console.log(`-----------------`)
console.log()
console.log(`Join Our ${"Discord".rainbow} : https://discord.gg/QgEZQtabXc`)
console.log(`Made By ${"MinedPlumr".bold}, ${"wow_1.".bold}`)
console.log(`ⓒ 2024. WebSocket Research Team All rights reserved.`)
console.log(`Code Supporter : sanand0, https://github.com/sanand0/minecraft-websocket/tree/master/tutorial#programming-minecraft-with-websockets`)
console.log()
console.log(`----------------- `)

console.log(l.AutoReloaderIsOn)
console.log(l.IfNotConnected)

wss.on('connection', socket => {
    console.log(l.HowToStopConnect)
    send(`tellraw @a { "rawtext": [{ "text": "${l.AutoReloaderConnectedMinecraft}" }] }`)

    setInterval(() => {
        send(`reload`)
        if (setting.autoReloaderMessageOnOff) {
            send(`tellraw @a { "rawtext": [{ "text": "${setting.autoReloaderMessage}" }] }`)
        }
    }, setting.autoReloaderDelay);

    socket.send(JSON.stringify({
        "header": {
            "version": 1,
            "requestId": generated_uuid,
            "messageType": "commandRequest",
            "messagePurpose": "subscribe"
        },
        "body": {
            "eventName": "PlayerMessage"
        },
    }))

    function send(cmd) {
        const msg = {
            "header": {
                "version": 1,
                "requestId": uuid.v4(),
                "messagePurpose": "commandRequest",
                "messageType": "commandRequest"
            },
            "body": {
                "version": 1,
                "commandLine": cmd,
                "origin": {
                    "type": "player"
                }
            }
        }
        socket.send(JSON.stringify(msg))
    }

    socket.on('close', function () {
        process.exit(0)
    })
})
const setting = {
    autoReloaderDelay: 1000, // AutoReloader 딜레이를 설정한다. (밀리초 단위, 1000밀리초 = 1초)
    autoReloaderMessageOnOff: true, // reload될때 서버내 모든내 플레이어에게 메시지를 표시할지
    autoReloaderMessage: "Changes saved", // reload될때 서버내 모든플레이어에게 표시할 메시지
    port: 3000,

    lang: `ko` // en, ko
}

module.exports = setting // 설정을 내보냄
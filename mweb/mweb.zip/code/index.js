const express = require("express");
const path = require("path");  // 경로를 처리하기 위해 사용
const { Server } = require("socket.io");
const WebSocket = require("ws");
const uuid = require("uuid");
const http = require("http");
const setting = require("../setting")
const { exec } = require("child_process")
const colors = require(`colors`)
console.log(`-----------------`)
console.log()
console.log(`Join Our ${"Discord".rainbow} : https://discord.gg/QgEZQtabXc`)
console.log(`Made By ${"wow_1.".bold}`)
console.log(`ⓒ 2024. WebSocket Research Team All rights reserved.`)
console.log(`Code Supporter : sanand0, https://github.com/sanand0/minecraft-websocket/tree/master/tutorial#programming-minecraft-with-websockets`)
console.log()
console.log(`----------------- `)
let remoteCommand = {}
let send

// Express 서버 설정
const app = express();
const port = setting.webport;

// HTTP 서버 생성
const server = http.createServer(app);

// Socket.io 서버 설정
const io = new Server(server);

// HTML 파일을 클라이언트에게 제공
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "web.html"));  // HTML 파일 경로 설정
});

// Express 서버 시작
server.listen(port, () => {
    console.log(`웹서버 http://localhost:${port} 실행 성공.\n연결 시 자동으로 사이트가 열립니다.`);
});

// WebSocket 서버 설정
const wss = new WebSocket.Server({ port: setting.port }); // WebSocket 서버는 다른 포트를 사용
console.log('"/connect 127.0.0.1:' + setting.port + '"을 마인크래프트에 입력해, 클라이언트 측과 연결하세요!');

// WebSocket 서버에 클라이언트 연결 시 동작
wss.on("connection", (socket) => {
    console.log("연결 성공");
    exec("explorer http://127.0.0.1:" + setting.webport)

    socket.on("message", packet => {
        const msg = JSON.parse(packet)

        console.log(msg)

        if (msg.body.type == "chat") {
            io.emit("c", msg.body.sender, msg.body.message)
        } else {
            io.emit("dc", msg.body.message)
        }
        if (msg.body.statusMessage) {
            io.emit("sm", msg.body.statusMessage)
        }
    })

    // Minecraft에서 모든 채팅 메시지를 구독하기 위한 요청
    socket.send(
        JSON.stringify({
            header: {
                version: 1, // Use version 1 message protocol
                requestId: uuid.v4(), // A unique ID for the request
                messageType: "commandRequest", // This is a request ...
                messagePurpose: "subscribe", // ... to subscribe to ...
            },
            body: {
                eventName: "PlayerMessage", // ... all player messages.
            },
        })
    );

    // MineCraft에 명령어를 보내는 함수
    send = (cmd) => {
        const msg = {
            header: {
                version: 1,
                requestId: uuid.v4(), // Send unique ID each time
                messagePurpose: "commandRequest",
                messageType: "commandRequest",
            },
            body: {
                version: 1,
                commandLine: cmd, // Define the command
                origin: {
                    type: "player", // Message comes from player
                },
            },
        };
        socket.send(JSON.stringify(msg)); // Send the JSON string
    }
});

// Socket.io 서버에 연결 시 동작
io.on("connection", (socket) => {
    console.log("Socket.io 연결 성공");

    socket.on("goforward", () => {
        send("agent move forward");
    });

    //goUp
    socket.on("goUp", () => {
        send("agent move up");
    });
    //goDown
    socket.on("goDown", () => {
        send("agent move down");
    });
    //goBack
    socket.on("goBack", () => {
        send("agent move back");
    })

    socket.on("rotateLeft", () => {
        send("agent turn left");
    });

    socket.on("rotateRight", () => {
        send("agent turn right");
    });

    socket.on("sendChat", val => {
        send(val)
    })
    // destroy
    socket.on("destroy", () => {
        send("agent destroy forward");
    })
    // tp
    socket.on("tp", () => {
        send("agent tp");
    })
    // "tellraw_print"
    socket.on("tellraw_print", (a, b) => {
        send(`tellraw ${a} {"rawtext":[{"text":"${b.replace(/\\/, "\\\\").replace(/\"/g, "\\\"").replace(/\n/g, "\\n")}"}]}`)
    })

    socket.on("me_print", x => {
        send(`me ${x}`)
    })
});
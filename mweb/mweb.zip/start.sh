echo "Minecraft Master WebSocket"
node ./code/index.js
read -p "Press Enter to continue..."
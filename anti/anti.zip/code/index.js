const WebSocket = require('ws')
const uuid = require('uuid')
const path = require(`path`)
const colors = require(`colors`)
const setting = require(path.join(__dirname, `..`, `setting.js`))
const wss = new WebSocket.Server({ port: setting.port })

console.log(`-----------------`)
console.log()
console.log(`Join Our ${"Discord".rainbow} : https://discord.gg/QgEZQtabXc`)
console.log(`Made By ${"MinedPlumr".bold}`)
console.log(`ⓒ 2024. WebSocket Research Team All rights reserved.`)
console.log(`Code Supporter : sanand0, https://github.com/sanand0/minecraft-websocket/tree/master/tutorial#programming-minecraft-with-websockets`)
console.log()
console.log(`----------------- `)

console.log(`준비되었다면 '/connect localhost:${setting.port}'를 마인크래프트 채팅창에 입력해 연결하세요.`)
console.log(`${"주의 : 외부공격이 감지되면 모든사람 채팅이 제한됩니다.".red}`)

wss.on('connection', socket => {
    console.log(`연결됨`)

    socket.send(JSON.stringify({
        "header": {
            "version": 1,
            "requestId": uuid.v4(),
            "messageType": "commandRequest",
            "messagePurpose": "subscribe"
        },
        "body": {
            "eventName": "PlayerMessage"
        },
    }))
    function send(cmd) {
        const msg = {
            "header": {
                "version": 1,
                "requestId": uuid.v4(),
                "messagePurpose": "commandRequest",
                "messageType": "commandRequest"
            },
            "body": {
                "version": 1,
                "commandLine": cmd,
                "origin": {
                    "type": "player"
                }
            }
        }
        socket.send(JSON.stringify(msg))
    }

    function tellraw(msg1) {
        const msg = {
            "header": {
                "version": 1,
                "requestId": uuid.v4(),
                "messagePurpose": "commandRequest",
                "messageType": "commandRequest"
            },
            "body": {
                "version": 1,
                "commandLine": `tellraw @a {"rawtext":[{"text":"${msg1}"}]}`,
                "origin": {
                    "type": "player"
                }
            }
        }
        socket.send(JSON.stringify(msg))
    }
    socket.on('message', packet => {
        const pc = JSON.parse(packet)

        if (pc.header.eventName == "PlayerMessage") {
            if (pc.body.sender == `외부` && !pc.body.receiver) {
                if (pc.body.type == `me` || pc.body.type == `tell`) {
                    tellraw(`§e[ Anti WebSocket ] 외부 공격이 차단되었습니다. ( ${pc.body.message} )`)
                    tellraw(`§e[ Anti WebSocket ] 채팅제한을 푸실려면 '/ability @a mute false'를 채팅에 입력해주세요.`)
                    console.log(`외부채팅 감지됨 : ${pc.body.message}`)
                    console.log(`외부채팅 감지됨'/ability @a mute false'를 채팅에 입력해 채팅제한을 비허용하세요.`)
                    send(`ability @a mute true`)
                }
            }
        }

    })
})


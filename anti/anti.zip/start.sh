echo "WebSocket Anti WebSocket"
node ./code/index.js
read -p "Press enter to continue"
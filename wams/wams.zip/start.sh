echo "WebSocket Auto MaxPlayer Set"
node ./code/index.js
echo "Press any key to continue..."
read -n 1 -s
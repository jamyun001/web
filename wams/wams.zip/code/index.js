const WebSocket = require('ws')
const uuid = require('uuid')
const path = require('path')
const colors = require('colors')
const setting = require(path.join(__dirname, `..`, `setting.js`))
const wss = new WebSocket.Server({ port: setting.port })

console.log(`-----------------`)
console.log()
console.log(`Join Our ${"Discord".rainbow} : https://discord.gg/QgEZQtabXc`)
console.log(`Made By ${"wow_1.".bold}`)
console.log(`ⓒ 2024. WebSocket Research Team All rights reserved.`)
console.log(`Code Supporter : sanand0, https://github.com/sanand0/minecraft-websocket/tree/master/tutorial#programming-minecraft-with-websockets`)
console.log()
console.log(`-----------------`)

console.log(`준비되었다면 마인크래프트 채팅에 '/connect localhost:${setting.port}'를 입력해주세요.`)

wss.on('connection', socket => {
  console.log('연결됨, 이제부터 자동으로 인원수를 조절합니다.')

  socket.send(JSON.stringify({
    "header": {
      "version": 1,
      "requestId": uuid.v4(),
      "messageType": "commandRequest",
      "messagePurpose": "subscribe"
    },
    "body": {
      "eventName": "PlayerMessage"
    },
  }))

  function send(cmd) {
    const msg = {
      "header": {
        "version": 1,
        "requestId": uuid.v4(),
        "messagePurpose": "commandRequest",
        "messageType": "commandRequest"
      },
      "body": {
        "version": 1,
        "commandLine": cmd,
        "origin": {
          "type": "player"
        }
      }
    }
    socket.send(JSON.stringify(msg))
  }

  socket.on('message', packet => {
    const msg = JSON.parse(packet)
    if (msg.body.currentPlayerCount && msg.body.maxPlayerCount && msg.body.players) {
      send("setmaxplayers " + (msg.body.currentPlayerCount + 1))
    }
  })

  setInterval(function () {
    send('list')
  }, 100)
})
#!/bin/bash

while true; do
    echo "Starting index.js..."
    nohup node index.js &  # 백그라운드에서 실행

    # 600초(10분) 동안 대기
    sleep 600

    # node 프로세스 종료
    pkill -f node
    echo "index.js process terminated."
done
echo "WebSocket Chat Recorder"
node ./code/index.js
read -n1 -r -p "Press any key to continue..."
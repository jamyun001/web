const WebSocket = require('ws')
const uuid = require('uuid')
const colors = require("colors")
const path = require(`path`)
const fs = require(`fs`)
const setting = require(path.join(__dirname, `..`, `setting.js`))
const wss = new WebSocket.Server({ port: setting.port })

console.log(`-----------------`)
console.log()
console.log(`Join Our ${"Discord".rainbow} : https://discord.gg/QgEZQtabXc`)
console.log(`Made By ${"MinedPlumr".bold}, ${"wow_1.".bold}`)
console.log(`ⓒ 2024. WebSocket Research Team All rights reserved.`)
console.log(`Code Supporter : sanand0, https://github.com/sanand0/minecraft-websocket/tree/master/tutorial#programming-minecraft-with-websockets`)
console.log()
console.log(`----------------- `)

console.log(`Ready, Type '/connect localhost:${setting.port}" in your minecraft chat`)

wss.on('connection', socket => {
    console.log('Connected')

    socket.send(JSON.stringify({
        "header": {
            "version": 1,
            "requestId": uuid.v4(),
            "messageType": "commandRequest",
            "messagePurpose": "subscribe"
        },
        "body": {
            "eventName": "PlayerMessage"
        },
    }))

    function send(cmd) {
        const msg = {
            "header": {
                "version": 1,
                "requestId": uuid.v4(),
                "messagePurpose": "commandRequest",
                "messageType": "commandRequest"
            },
            "body": {
                "version": 1,
                "commandLine": cmd,
                "origin": {
                    "type": "player"
                }
            }
        }
        socket.send(JSON.stringify(msg))
    }

    socket.on('message', packet => {
        const msg = JSON.parse(packet)
        if (msg.body.type == "chat") {
            const data = JSON.parse(fs.readFileSync(path.join(__dirname, `..`, `chat.json`)))
            data.push({ sender: msg.body.sender, message: msg.body.message, date: new Date().toString() })
            console.log(data)
            fs.writeFileSync(path.join(__dirname, `..`, `chat.json`), JSON.stringify(data, false, 4))
        }
    })
})
echo "WikiPedia Search WebSocket"
node ./code/index.js
read -p "종료하려면 [Enter]를 누르세요..."
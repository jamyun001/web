const WebSocket = require('ws')
const uuid = require('uuid')
const axios = require("axios")
const path = require(`path`)
const setting = require(path.join(__dirname, `..`, `setting.js`))
const colors = require(`colors`)

console.log(`-----------------`)
console.log()
console.log(`Join Our ${"Discord".rainbow} : https://discord.gg/QgEZQtabXc`)
console.log(`Made By ${"wow_1.".bold}`)
console.log(`ⓒ 2024. WebSocket Research Team All rights reserved.`)
console.log(`Code Supporter : sanand0, https://github.com/sanand0/minecraft-websocket/tree/master/tutorial#programming-minecraft-with-websockets`)
console.log()
console.log(`----------------- `)

console.log(`마인크래프트에서 '/connect localhost:${setting.port}'를 입력해주세요`)
console.log(`사용법은 디스코드를 참조하세요.`)
const wss = new WebSocket.Server({ port: setting.port })

wss.on('connection', socket => {
  console.log('연결 성공')
  send("/me §l§e마인크래프트 위키백과 검색 WebSocket이 연결되었습니다. ( @s )")

  socket.send(JSON.stringify({
    "header": {
      "version": 1,
      "requestId": uuid.v4(),
      "messageType": "commandRequest",
      "messagePurpose": "subscribe"
    },
    "body": {
      "eventName": "PlayerMessage"
    },
  }))

  function send(cmd) {
    const msg = {
      "header": {
        "version": 1,
        "requestId": uuid.v4(),
        "messagePurpose": "commandRequest",
        "messageType": "commandRequest"
      },
      "body": {
        "version": 1,
        "commandLine": cmd,
        "origin": {
          "type": "player"
        }
      }
    }
    socket.send(JSON.stringify(msg))
  }

  socket.on('message', async packet => {
    const msg = JSON.parse(packet)
    if (msg.body.type == "chat") {
      const message = msg.body.message
      const split = message.split(" ")
      const join = split.slice(1).join(" ")

      if (split[0] == "!wiki") {
        send(`me §e위키백과 검색중 : ${join}`)
        console.log(`위키백과 검색중 : ${join}`)
        try {
          const x = await axios.get("https://ko.wikipedia.org/api/rest_v1/page/summary/" + join)
          console.log(x)
          send(`me §e위키백과 내용 분석 결과:\n§r  ${x.data.extract}`)
        } catch (err) {
          console.log(err)
          send(`me §e에러 코드:§r ${err.status}`)
        }
      }
    }

    socket.on('close', packet => {
      console.log(`웹소켓 서버가 닫혔습니다.`)
      process.exit(0)
    })
  })
})
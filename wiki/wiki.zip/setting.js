const setting = {
    port: 3000
}

module.exports = setting
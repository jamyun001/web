const WebSocket = require('ws')
const uuid = require('uuid')
const TinyURL = require('tinyurl');
const path = require(`path`)
const setting = require(path.join(__dirname, `..`, `setting.js`))
const wss = new WebSocket.Server({ port: setting.port });
const colors = require(`colors`)

console.log(`-----------------`)
console.log()
console.log(`Join Our ${"Discord".rainbow} : https://discord.gg/QgEZQtabXc`)
console.log(`Made By ${"wow_1.".bold}`)
console.log(`ⓒ 2024. WebSocket Research Team All rights reserved.`)
console.log(`Code Supporter : sanand0, https://github.com/sanand0/minecraft-websocket/tree/master/tutorial#programming-minecraft-with-websockets`)
console.log()
console.log(`----------------- `)

console.log(`준비 되셨다면, 마인크래프트 채팅에 '/connect localhost:${setting.port}'를 적어주세요.`)

wss.on('connection', socket => {
  console.log("연결됨, 사용법은 디스코드를 참고해주세요.");

  socket.on("message", function (packet) {
    const msg = JSON.parse(packet);

    if (msg.body.type == "chat" && msg.body.sender == setting.auth) {
      const message = msg.body.message
      const split = message.split(" ")
      const arg2 = split.slice(1).join(" ")

      if (split[0] == "!shortUrl") {
        TinyURL.shorten(arg2).then(function (res) {
          send(`me | §l결과§r: ${res}`)
        }).catch(function (err) {
          console.log("한도 제한이거나 다른 에러가 발생했습니다: " + err)
        })
      }
    }
  });

  socket.on("close", function () {
    console.log("연결이 끊겼습니다.");
    process.exit(0)
  })

  socket.send(
    JSON.stringify({
      header: {
        version: 1,
        requestId: uuid.v4(),
        messageType: "commandRequest",
        messagePurpose: "subscribe",
      },
      body: {
        eventName: "PlayerMessage",
      },
    })
  );

  function send(cmd) {
    const msg = {
      header: {
        version: 1,
        requestId: uuid.v4(),
        messagePurpose: "commandRequest",
        messageType: "commandRequest",
      },
      body: {
        version: 1,
        commandLine: cmd,
        origin: {
          type: "player",
        },
      },
    };
    socket.send(JSON.stringify(msg));
  }
})

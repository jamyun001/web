//Node Js Import
const path = require(`path`)
const setting = require(path.join(__dirname, `..`, `setting.js`))
const WebSocket = require('ws')
const uuid = require('uuid')
const wss = new WebSocket.Server({ port: setting.port })
const colors = require(`colors`)
let connected = false

console.log(`-----------------`)
console.log()
console.log(`Join Our ${"Discord".rainbow} : https://discord.gg/QgEZQtabXc`)
console.log(`Made By ${"MinedPlumr".bold}`)
console.log(`ⓒ 2024. WebSocket Research Team All rights reserved.`)
console.log(`Code Supporter : sanand0, https://github.com/sanand0/minecraft-websocket/tree/master/tutorial#programming-minecraft-with-websockets`)
console.log()
console.log(`----------------- `)

console.log(`준비됨, 마인크래프트 채팅에서 '/connect localhost:${setting.port}'를 입력하세요.`)

wss.on('connection', (socket, req) => {
    const readline = require('readline');
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
    });
    start()
    if (connected == true) {
        console.log(`이중 연결이 감지되었습니다.`)
        process.exit(0)
    }
    connected = true
    console.log(`연결됨, 명령어 프롬프트에 채팅을 치세요.`)
    function start() {
        rl.question(``, value => {
            if (value.length == 0) {
                console.log(`외부 채팅은 1글자 이상이여야 합니다.`)
            } else {
                Command(`me ${value}`)
            }
            start()
        });
    }

    function Command(cmd) {
        const packet = {
            "header": {
                "version": 1,
                "requestId": uuid.v4(),
                "messagePurpose": "commandRequest",
                "messageType": "commandRequest"
            },
            "body": {
                "version": 1,
                "commandLine": cmd,
                "origin": {
                    "type": "player"
                }
            }
        };
        socket.send(JSON.stringify(packet));
    }
    socket.send(JSON.stringify({
        "header": {
            "version": 1,
            "requestId": uuid.v4(),
            "messageType": "commandRequest",
            "messagePurpose": "subscribe"
        },
        "body": {
            "eventName": "PlayerMessage"
        },
    }))

    socket.on('close', function () {
        console.log(`연결 해제됨`)
        process.exit(0)
    })
})
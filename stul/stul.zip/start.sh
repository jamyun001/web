echo "WebSocket URL shortener"
node ./code/index.js
read -p "Press enter to continue"
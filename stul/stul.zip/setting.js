const setting = {
    port: 3000,
    auth: "PlumrMined"
}

module.exports = setting